<?php

 $email = $_POST['email'];
 $sifre = $_POST['sifre'];
 
 if($email == 'b181210045@sakarya.edu.tr' && $sifre == '123456'){
 	echo "Hoşgeldiniz b181210045";
 	echo "<p> <a href='hakkimda.html'> &lt; ANASAYFAYA DÖN &gt; </a> </p>";
 }
 else{
	echo  "E-posta veya şifre hatalı.";
	echo "<p> <a href='giris.html'> &lt; GERİ DÖN &gt; </a> </p>";
 }
 
?>
