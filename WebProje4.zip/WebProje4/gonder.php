<?php

 $name = $_POST['name'];
 $surname = $_POST['surname'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $message = $_POST['message'];
 $cinsiyet = $_POST['cinsiyet'];
 $konular = $_POST['konular'];
 echo "Ad: ".$name."<br>"; echo "Soyad: ".$surname."<br>";
 echo "E-posta: ".$email."<br>"; echo"Tel No: ".$phone."<br>";
 echo "Cinsiyet: ".$cinsiyet."<br>"; echo"Konu: ".$konular."<br><br>";
 echo "Mesaj: <br>".$message;	


?>